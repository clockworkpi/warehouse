#!/bin/bash

love DCDOR_final_fixEnding.love
