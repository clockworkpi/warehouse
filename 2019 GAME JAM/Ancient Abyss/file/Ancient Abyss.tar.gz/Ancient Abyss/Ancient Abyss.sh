LD_LIBRARY_PATH=~/apps/nwjs-sdk-v0.27.6-linux-arm/lib ~/apps/nwjs-sdk-v0.27.6-linux-arm/nw package.nw --no-sandbox --no-sandbox-and-elevated --disable-gpu --force-cpu-draw
