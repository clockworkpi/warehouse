## Install instructions

* Unzip the attachment
* Copy the package.nw folder under ~/apps/nwjs-sdk-v0.27.6-linux-arm/
* Copy the .sh file to ~/launcher/Menu/GameShell/
* Copy the .png icon to ~/launcher/skin/default/Menu/GameShell/
* Reload the launcher then a new item should appear
