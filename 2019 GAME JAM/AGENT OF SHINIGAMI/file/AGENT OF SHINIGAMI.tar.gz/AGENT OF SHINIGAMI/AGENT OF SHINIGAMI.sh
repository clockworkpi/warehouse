#!/bin/bash

retroarch -L mgba_libretro.so AGENT\ OF\ SHINIGAMI.gb
