#!/bin/bash

love Metal\ Fighter.love
