pip install pygame
python main.py