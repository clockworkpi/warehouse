#!/bin/bash

LD_LIBRARY_PATH=. ./scratch -splore -draw_rect 32,0,256,240

