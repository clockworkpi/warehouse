#!/bin/bash

LD_LIBRARY_PATH=. ./robogame -splore -draw_rect 32,0,256,240

